const inputPrefix = 'dsh-team-chat:'

export function roomInputId(run) {
  return inputPrefix + run.id
}

function belongsTo(run, message) {
  return message.source.kind === 'user' && message.source.rpcId === roomInputId(run)
}

export function isStaleRoomInput(run, message) {
  if (message.source.kind !== 'user' || !message.source.rpcId?.startsWith(inputPrefix)) return false
  return !run || run.finished || run.signal?.aborted || !belongsTo(run, message)
}

export function claimRoomTurn(run, message, turn) {
  if (run && !run.finished && belongsTo(run, message)) run.claimed = turn
}

export function discardRoomInput(run, message) {
  if (!run || run.finished || !belongsTo(run, message)) return
  run.finished = true
  run.done.resolve({ kind: 'aborted' })
}

export function observeRoomTurn(run, session, event) {
  if (!run || run.memberId !== session.id || run.finished) return
  const data = event.data
  switch (event.type) {
    case 'assistant/message':
      if (run.claimed === data.turn) {
        const answer = data.message.content.filter(block => block.type === 'text').map(block => block.text).join('')
        if (answer) run.text = answer.slice(0, 12_000)
        run.live = ''
      }
      break
    case 'turn/end':
      if (run.claimed !== data.turn) break
      run.finished = true
      run.done.resolve(data.reason)
      break
  }
}

export function observeRoomStream(run, frame) {
  if (!run || run.finished || run.claimed === undefined) return
  if (frame.type === 'start') {
    if (frame.turn !== run.claimed) return
    run.attempt = frame.attemptId
    run.live = ''
  }
  if (frame.type === 'chunk' && frame.attemptId === run.attempt && frame.chunk.type === 'text-delta') {
    run.live = (run.live + frame.chunk.text).slice(0, 12_000)
  }
}

export function stopRoomTurn(run, agent) {
  if (!run || !agent || run.finished) return
  if (run.claimed !== undefined) {
    agent.cancel({ kind: 'user' }, { keepInbox: true })
    return
  }
  const queued = agent.inbox.nextTurn.find(message => belongsTo(run, message))
  if (queued) agent.inbox.remove(queued.id)
}

export function nativeAttention(run) {
  if (!run?.attention?.size) return undefined
  return [...run.attention.values()].find(item => item.kind === 'approval') ?? run.attention.values().next().value
}

export async function observeNativeAttention(run, detail, next, changed) {
  if (!run || run.claimed === undefined || run.finished) return next()
  run.attention ??= new Map()
  const token = Symbol()
  run.attention.set(token, detail)
  changed()
  try {
    return await next()
  } finally {
    run.attention.delete(token)
    changed()
  }
}
