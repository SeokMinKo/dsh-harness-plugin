import { createHash } from 'node:crypto'
import { constants } from 'node:fs'
import { open, realpath, stat } from 'node:fs/promises'
import { isAbsolute, relative, resolve, sep } from 'node:path'

export function workspacePath(root, input) {
  if (!root) throw new Error('DSH 원본 세션에 작업 공간을 지정하세요.')
  const path = resolve(root, input)
  const local = relative(root, path)
  if (isAbsolute(input) || isAbsolute(local) || local === '..' || local.startsWith('..' + sep)) {
    throw new Error('작업 공간 내부의 상대 경로를 사용하세요. ' + input)
  }
  return path
}

export async function verifiedPath(root, input) {
  if (!root) throw new Error('DSH 원본 세션에 작업 공간을 지정하세요.')
  const base = await realpath(root)
  const path = await realpath(workspacePath(base, input))
  const local = relative(base, path)
  if (isAbsolute(local) || local === '..' || local.startsWith('..' + sep)) throw new Error('작업 공간 밖을 가리키는 경로입니다.')
  return path
}

export function fingerprint(file) {
  return [file.dev, file.ino, file.size, file.mtimeMs, file.ctimeMs].join(':')
}

export async function hashFile(root, input) {
  const path = await verifiedPath(root, input)
  const handle = await open(path, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0) | (constants.O_NONBLOCK ?? 0))
  try {
    const before = await handle.stat()
    if (!before.isFile()) throw new Error('일반 파일이 필요합니다. ' + input)
    const hash = createHash('sha256')
    for await (const block of handle.createReadStream({ autoClose: false })) hash.update(block)
    const after = await stat(await verifiedPath(root, input))
    if (fingerprint(before) !== fingerprint(after)) throw new Error('파일이 바뀌었습니다. ' + input)
    return { path: input, bytes: before.size, sha256: hash.digest('hex'), stamp: fingerprint(after) }
  } finally {
    await handle.close()
  }
}
